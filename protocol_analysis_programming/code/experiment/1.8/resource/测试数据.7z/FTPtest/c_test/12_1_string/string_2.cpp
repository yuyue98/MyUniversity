#include "MyString.h"

void callme1(MyString& rsb) {
	cout<<"String passed by reference:";
	cout<<"\""<<rsb.length()<<"\""<<endl;
}

void callme2(MyString sb) {
	cout<<"String passed by value:";
	cout<<"\""<<sb<<"\""<<endl;
}

int main() {
	MyString a;
	MyString b("123456");
	callme1(a);
	cout<<a<<endl;
	callme2(b);
	cout<<b<<endl;
	MyString c;
	c = a;
	cout<<c<<endl;
	MyString d; 
	d = "1234";
	cout<<d<<endl;
	return 0;
}
