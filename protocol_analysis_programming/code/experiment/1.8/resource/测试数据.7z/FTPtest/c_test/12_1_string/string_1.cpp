#include "StringBad.h"

void callme1(StringBad& rsb) {
	cout<<"String passed by reference:"<<endl;
	cout<<"\""<<rsb<<"\""<<endl;
}

void callme2(StringBad sb) {
	cout<<"String passed by value:"<<endl;
	cout<<"\""<<sb<<"\""<<endl;
}

int main() {
	StringBad a;
	StringBad b("123456");
	callme1(a);
	cout<<a<<endl;
	callme2(b);
	cout<<b<<endl;
	StringBad c;
	c = a;
	cout<<c<<endl;
	return 0;
}
