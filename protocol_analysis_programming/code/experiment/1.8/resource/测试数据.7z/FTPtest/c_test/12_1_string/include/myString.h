#ifndef MYSTRING_H_
#define MYSTRING_H_

#include <iostream>
#include <cstring>

using namespace std;

class MyString {
	private:
		char* str;
		int len;
		static int num_strings;
		static const int CINLIM;
	public:
		MyString();
		MyString(const char* s);
		MyString(const MyString& st); 
		MyString& operator=(const MyString& st);
		MyString& operator=(const char* st);
		~MyString();
		
		static int HowMany();
		int length() const { return len; };
		char& operator[](int i);
		const char& operator[](int i) const;
		
		friend istream& operator>>(istream& is, const MyString& st);
		friend ostream& operator<<(ostream& os, const MyString& st);
		friend bool operator<(const MyString& st, const MyString& st2);
		friend bool operator>(const MyString& st, const MyString& st2);
		friend bool operator==(const MyString& st, const MyString& st2);
		
		
		
};

#endif
