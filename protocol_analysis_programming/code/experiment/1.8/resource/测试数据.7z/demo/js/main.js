var app = new Vue({
    el: '#app',
    data: {
        isAllGet: false,
        list:[
            {
                id: 1,
                name: 'iPhone 7',
                price: 6188,
                count: 1,
                isGet: false,
                priceChange: false
            },
            {
                id: 2,
                name: 'iPad Pro',
                price: 5888,
                count: 1,
                isGet: false,
                priceChange: false
            },
            {
                id: 1,
                name: 'MacBook Pro',
                price: 21488,
                count: 1,
                isGet: false,
                priceChange: false
            }
        ]
    },
    computed: {
        totalPrice:function(){
            var total = 0;
            for (var i = 0;i < this.list.length;i++){
                var item = this.list[i];
                if (item.isGet)
                    total += item.price * item.count;
            }
            return total.toString().replace(/\B(?=(\d{3})+$)/g,',');
        }
    },
    methods: {
        handleReduce: function (index) {
            if (this.list[index].count === 1) return;
            this.list[index].count--;
        },
        handleAdd: function (index) {
            this.list[index].count++;
        },
        handleRemove: function (index) {
            this.list.splice(index,1);
        },
        getThis: function(index) {
            this.list[index].isGet = this.list[index].isGet === false ? true : false;
        },
        allGet: function () {
            this.isAllGet = this.isAllGet === false ? true : false;
            for (var i = 0;i <this.list.length;i++){
                var item = this.list[i];
                item.isGet = this.isAllGet;
            }
        },
        priceChangeClick:function(index){
            this.list[index].priceChange = this.list[index].priceChange === false ? true : false;
        }
    }
});